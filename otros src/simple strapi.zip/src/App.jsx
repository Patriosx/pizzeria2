import React, { useEffect } from "react";
import "./styles.css";
import { useState } from "react";
import Formulario from "./components/Formulario";

const App = () => {
	//EN CASO DE QUE NO TE ACTUALICE AL LLAMAR A LAS FUNCIONES. AGREGAR async(funcion) y await(fetch)
	//url para coger los datos de strapi
	const url = "http://localhost:1337/todos";
	const [tareas, setTareas] = useState([]);

	/************************************/
	const getData2 = async () => {
		try {
			const response = await fetch(url);
			const json = await response.json();
			setTareas(json);
			console.log(json);
		} catch (error) {
			console.log(error);
		}
	};

	useEffect(() => {
		getData2();
	}, []);
	/************************************/

	const createTask = (nuevaTarea) => {
		const url = "http://localhost:1337/todos";
		//para pasarle el valor manualmente
		/*
		//body
		const tarea = {
			Task: "Entender strApi",
			Date: "2021-10-10",
		};*/
		// request options
		const options = {
			method: "POST",
			body: JSON.stringify(nuevaTarea),
			headers: {
				"Content-Type": "application/json",
			},
		};
		// send POST request
		fetch(url, options)
			.then((res) => res.json())
			.then((res) => console.log(res))
			.catch((err) => console.log(err));
	};
	/************************************/
	const eliminarTarea = (idTarea) => {
		const deleteURL = `http://localhost:1337/todos/${idTarea}`;
		const options = {
			method: "DELETE",
			headers: {
				"Content-Type": "application/json",
			},
		};
		// send DELETE request
		fetch(deleteURL, options)
			.then((res) => res.json())
			.catch((err) => console.log(err));
	};
	/************************************/
	const modificarTask = (idTarea) => {
		const putUrl = `http://localhost:1337/todos/${idTarea}`;
		//cambio el contenido que este en la bbdd por el objeto tarea
		const tarea = {
			Task: "(modificado)",
			Date: "1877-10-10",
		};
		// request options
		const options = {
			method: "PUT",
			body: JSON.stringify(tarea),
			headers: {
				"Content-Type": "application/json",
			},
		};
		// solicito PUT request
		fetch(putUrl, options)
			.then((res) => res.json())
			.catch((err) => console.log(err));
	};
	/************************************/
	//AQUI VA LA INTERFAZ
	return (
		<div className="container">
			<h1 className="text-center" id="title">
				TODO LIST
			</h1>
			<div className="card p-4 m-1">
				<Formulario crearTarea={createTask} />
			</div>
			{tareas.map((tarea) => {
				return (
					<div className="card p-2 m-1 ui segment">
						<h3>
							Tarea {tarea.id}: {tarea.Task}
						</h3>
						<p>Fecha: {tarea.Date}</p>
						<p>Completado: {tarea.Done.toString()}</p>
						<div className="container">
							<a href="/" onClick={() => eliminarTarea(tarea.id)}>
								Eliminar
							</a>
							<span> </span>
							<a href="/" onClick={() => modificarTask(tarea.id)}>
								Editar
							</a>
						</div>
					</div>
				);
			})}
		</div>
	);
};
export default App;
